*main_usr_foot.h
      if (process.GE.3) then
        call PDFSTA
      endif
