      external fncep_epee,fncep_epmm,fncep_eptt,fncep_eXee,fncep_eXmm
     & ,fncep_eXtt,fnceu_euee,fnceu_eumm,fnceu_eutt,fnceub_eubee,fnceub_eubmm
     & ,fnceub_eubtt,fnced_edee,fnced_edmm,fnced_edtt,fncedb_edbee,fncedb_edbmm
     & ,fncedb_edbtt,fnces_esee,fnces_esmm,fnces_estt,fncesb_esbee,fncesb_esbmm
     & ,fncesb_esbtt,fncec_ecee,fncec_ecmm,fncec_ectt,fncecb_ecbee,fncecb_ecbmm
     & ,fncecb_ecbtt,fnceb_ebee,fnceb_ebmm,fnceb_ebtt,fncebb_ebbee,fncebb_ebbmm
     & ,fncebb_ebbtt,fncet_etee,fncet_etmm,fncet_ettt,fncetb_etbee,fncetb_etbmm
     & ,fncetb_etbtt
